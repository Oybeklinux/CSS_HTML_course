$(document).ready(function(){
    $('.burgermenu').click(function(){
        $('.mob-menu').fadeToggle();
    })
})